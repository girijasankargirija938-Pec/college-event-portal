# Spectrum 2026 - College Event Portal

Pages: index.html, events.html, register.html, gallery.html, contact.html
Tech: HTML5, CSS3 (Grid, Flexbox, media queries), JavaScript (DOM, localStorage)

## Run
Double-click index.html, or use VS Code "Live Server" extension.

## Customise
- Event names, announcements, gallery items: top of js/main.js
- Fest date for countdown: `festDate` in js/main.js
- Colours: :root variables at top of css/style.css
- Real photos: put images in an `images/` folder, then in gallery section of main.js replace
  div.style.background with an <img src="images/photo1.jpg"> element.

## Host free
GitHub Pages (push repo -> Settings -> Pages) or drag folder to netlify.com/drop
