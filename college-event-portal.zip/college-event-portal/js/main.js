/* ============ DATA (like a mini database) ============ */
const events = [
  { id: 1, name: "Code Sprint", category: "Technical", day: "Day 1", time: "10:00 AM", venue: "Computer Lab 1", description: "Solve programming puzzles against the clock." },
  { id: 2, name: "Web Design Challenge", category: "Technical", day: "Day 1", time: "2:00 PM", venue: "Computer Lab 2", description: "Build a landing page using HTML, CSS and JS in 90 minutes." },
  { id: 3, name: "Tech Quiz", category: "Technical", day: "Day 2", time: "11:00 AM", venue: "Seminar Hall", description: "Team quiz on gadgets, software and general tech." },
  { id: 4, name: "Solo Singing", category: "Cultural", day: "Day 2", time: "3:00 PM", venue: "Main Auditorium", description: "Show your voice on stage. Any language." },
  { id: 5, name: "Group Dance", category: "Cultural", day: "Day 3", time: "10:00 AM", venue: "Main Auditorium", description: "Teams of 4 to 8 members. Time limit 5 minutes." },
  { id: 6, name: "Rangoli", category: "Cultural", day: "Day 1", time: "9:30 AM", venue: "Campus Courtyard", description: "Create a themed rangoli with colours." },
  { id: 7, name: "Cricket Tournament", category: "Sports", day: "Day 2", time: "8:00 AM", venue: "College Ground", description: "Inter-department knockout matches." },
  { id: 8, name: "Treasure Hunt", category: "Fun", day: "Day 3", time: "1:00 PM", venue: "Whole Campus", description: "Follow the clues in teams of three." }
];

const announcements = [
  "Registrations close on 20 November.",
  "Bring your college ID card to every event.",
  "The Web Design Challenge now allows teams of two.",
  "Free lunch coupons for all registered participants."
];

const galleryItems = [
  { title: "Opening ceremony", color: "#6d28d9" },
  { title: "Code Sprint 2025", color: "#0f766e" },
  { title: "Group dance finals", color: "#be185d" },
  { title: "Cricket final", color: "#15803d" },
  { title: "Rangoli contest", color: "#c2410c" },
  { title: "Tech quiz", color: "#1d4ed8" },
  { title: "Treasure hunt", color: "#a16207" },
  { title: "Prize distribution", color: "#7e22ce" }
];

/* ============ HELPER ============ */
// Builds the HTML for one event card
function eventCard(e) {
  return `
    <div class="card">
      <span class="tag">${e.category}</span>
      <h3>${e.name}</h3>
      <p>${e.description}</p>
      <p class="meta">${e.day} &middot; ${e.time} &middot; ${e.venue}</p>
      <a class="btn" href="register.html?event=${e.id}">Register</a>
    </div>`;
}

/* ============ MOBILE MENU (all pages) ============ */
document.getElementById("menu-btn").addEventListener("click", function () {
  document.getElementById("nav").classList.toggle("open");
});

/* ============ HOME PAGE ============ */
if (document.getElementById("announcements")) {
  const list = document.getElementById("announcements");
  announcements.forEach(function (text) {
    const li = document.createElement("li");
    li.textContent = text;
    list.appendChild(li);
  });

  // Show the first 3 events as "featured"
  document.getElementById("featured-events").innerHTML = events.slice(0, 3).map(eventCard).join("");

  // Countdown to the fest start date (change this date!)
  const festDate = new Date("2026-12-10T09:00:00");
  const countdown = document.getElementById("countdown");
  function updateCountdown() {
    const diff = festDate - new Date();
    if (diff <= 0) {
      countdown.textContent = "The fest has started!";
      return;
    }
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
    const mins = Math.floor((diff / (1000 * 60)) % 60);
    countdown.textContent = days + " days " + hours + " hrs " + mins + " mins to go";
  }
  updateCountdown();
  setInterval(updateCountdown, 60000);
}

/* ============ EVENTS PAGE ============ */
if (document.getElementById("event-list")) {
  const searchBox = document.getElementById("search");
  const categoryBox = document.getElementById("category");
  const listBox = document.getElementById("event-list");
  const countText = document.getElementById("count");

  function showEvents() {
    const text = searchBox.value.toLowerCase();
    const cat = categoryBox.value;
    const result = events.filter(function (e) {
      const matchText = e.name.toLowerCase().includes(text) || e.description.toLowerCase().includes(text);
      const matchCat = cat === "All" || e.category === cat;
      return matchText && matchCat;
    });
    listBox.innerHTML = result.length ? result.map(eventCard).join("") : "<p>No events found.</p>";
    countText.textContent = result.length + " events found";
  }
  searchBox.addEventListener("input", showEvents);
  categoryBox.addEventListener("change", showEvents);
  showEvents();

  // Schedule table, sorted by day
  const rows = events.slice().sort((a, b) => a.day.localeCompare(b.day));
  document.getElementById("schedule").innerHTML = rows
    .map((e) => `<tr><td>${e.day}</td><td>${e.time}</td><td>${e.name}</td><td>${e.venue}</td></tr>`)
    .join("");
}

/* ============ REGISTRATION PAGE ============ */
if (document.getElementById("reg-form")) {
  const form = document.getElementById("reg-form");
  const eventSelect = document.getElementById("event");

  // Fill the event dropdown from the data
  events.forEach(function (e) {
    const option = document.createElement("option");
    option.value = e.id;
    option.textContent = e.name + " (" + e.day + ")";
    eventSelect.appendChild(option);
  });

  // If we came from "Register" button on an event card: register.html?event=3
  const preselected = new URLSearchParams(window.location.search).get("event");
  if (preselected) eventSelect.value = preselected;

  function setError(id, message) {
    document.getElementById(id + "-error").textContent = message;
    const field = document.getElementById(id);
    if (field.type !== "checkbox") field.classList.toggle("invalid", message !== "");
  }

  function showRegistrations() {
    const saved = JSON.parse(localStorage.getItem("registrations")) || [];
    const list = document.getElementById("reg-list");
    list.innerHTML = saved.length ? "" : "<li>No registrations yet.</li>";
    saved.forEach(function (r) {
      const li = document.createElement("li");
      li.textContent = r.name + " - " + r.eventName;
      list.appendChild(li);
    });
  }
  showRegistrations();

  form.addEventListener("submit", function (e) {
    e.preventDefault(); // stop page from reloading
    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const phone = document.getElementById("phone").value.trim();
    const dept = document.getElementById("dept").value;
    const eventId = eventSelect.value;
    const agree = document.getElementById("agree").checked;
    let valid = true;

    // Validate each field
    if (name.length < 3) { setError("name", "Enter your full name (min 3 letters)."); valid = false; } else setError("name", "");
    if (!email.includes("@") || !email.includes(".")) { setError("email", "Enter a valid email address."); valid = false; } else setError("email", "");
    if (!/^[0-9]{10}$/.test(phone)) { setError("phone", "Phone number must be exactly 10 digits."); valid = false; } else setError("phone", "");
    if (dept === "") { setError("dept", "Please select your department."); valid = false; } else setError("dept", "");
    if (eventId === "") { setError("event", "Please select an event."); valid = false; } else setError("event", "");
    if (!agree) { setError("agree", "You must agree to the rules."); valid = false; } else setError("agree", "");

    if (!valid) return;

    const chosen = events.find((ev) => ev.id == eventId);
    const saved = JSON.parse(localStorage.getItem("registrations")) || [];
    saved.push({ name, email, phone, dept, eventName: chosen.name });
    localStorage.setItem("registrations", JSON.stringify(saved));

    const success = document.getElementById("success");
    success.textContent = "Thank you, " + name + "! You are registered for " + chosen.name + " on " + chosen.day + " at " + chosen.time + ".";
    success.classList.remove("hidden");
    form.reset();
    showRegistrations();
  });
}

/* ============ GALLERY PAGE ============ */
if (document.getElementById("gallery")) {
  const gallery = document.getElementById("gallery");
  const lightbox = document.getElementById("lightbox");
  const content = document.getElementById("lightbox-content");

  galleryItems.forEach(function (item) {
    const div = document.createElement("div");
    div.className = "photo";
    div.style.background = item.color;
    div.textContent = item.title;
    div.addEventListener("click", function () {
      content.innerHTML = `<div class="photo" style="background:${item.color}">${item.title}</div>`;
      lightbox.classList.remove("hidden");
    });
    gallery.appendChild(div);
  });

  document.getElementById("close-lightbox").addEventListener("click", function () {
    lightbox.classList.add("hidden");
  });
  lightbox.addEventListener("click", function (e) {
    if (e.target === lightbox) lightbox.classList.add("hidden");
  });
}

/* ============ CONTACT PAGE ============ */
if (document.getElementById("contact-form")) {
  document.getElementById("contact-form").addEventListener("submit", function (e) {
    e.preventDefault();
    const name = document.getElementById("c-name").value.trim();
    const email = document.getElementById("c-email").value.trim();
    const msg = document.getElementById("c-msg").value.trim();
    const error = document.getElementById("c-error");
    const success = document.getElementById("c-success");

    if (name === "" || !email.includes("@") || msg.length < 10) {
      error.textContent = "Fill all fields. Message must be at least 10 characters.";
      success.classList.add("hidden");
      return;
    }
    error.textContent = "";
    success.textContent = "Thanks " + name + ", we received your message and will reply soon.";
    success.classList.remove("hidden");
    this.reset();
  });
}
